class Screen {
    static SIGNUP = 'SignUp';
    static HOME = 'Home';
    static ALLBLOGS = 'AllBlogs';
    static MYBLOGS = 'MyBlogs';
    static ADDBLOG = 'AddBlog';
    static EDITBLOG = 'EditBlog';
}

export default Screen;