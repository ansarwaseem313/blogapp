<?php
	$connection = mysqli_connect('localhost','root','','db_blogs_app');
?>